Credits

1. Images

Demo images by http://lorempixel.com/

The images included in the theme's img/ folder are for demoing purposes only. Each image we use for this project is released under the creative commons license (CC BY-SA). For more information visit http://creativecommons.org/licenses/ 

2. Patterns

Patterns by Subtle Patterns (http://subtlepatterns.com/). 
Subtle Patterns by Subtle Patterns is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.